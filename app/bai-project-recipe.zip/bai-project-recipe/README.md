By default, I was using InnoDB and my database but InnoDB does not support FULLTEXT search.
As a result, I have switched over to using MyISAM as database engines for tables with a searchable file.
The tables are recipes and tags.

Example Query
SELECT r.*, MATCH(t.name, t.description, r.name, r.description) AGAINST ("bread" IN BOOLEAN MODE) AS relevancy FROM recipes r
RIGHT JOIN recipe_tags rt ON r.id = rt.recipe_id
RIGHT JOIN tags t ON t.id = rt.tag_id
WHERE r.id IS NOT NULL
HAVING relevancy > 0
ORDER BY relevancy DESC;
