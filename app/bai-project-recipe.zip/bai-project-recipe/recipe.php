<?php
include('header.php');
$recipe = $recipeService->findById(array("id" => $_GET["id"]));
?>
    <div class="container">

        <div class="row">
            <div class="box">
                <div class="col-lg-12">
                    <hr>
                    <h2 class="intro-text text-center">
                      <?php echo $recipe["name"]; ?>
                    </h2>
                    <hr>
                </div>
                <div class="col-md-6">
                    <img class="img-responsive img-border-left" src="<?php echo $imagePath . $recipe["image"]; ?>" alt="">
                </div>
                <div class="col-md-6">
                    <p>Preparation Time : <?php echo $recipe["preparation_time"]; ?></p>
                    <p>Cooking Time : <?php echo $recipe["cooking_time"]; ?></p>
                    <p>Serves : <?php echo $recipe["serves"]; ?></p>
                    <p>Chef : <?php echo $recipe["fullname"]; ?></p>
                    <p><?php echo $recipe["description"]; ?></p>
                </div>
                <div class="clearfix"></div>
            </div>
        </div>

        <div class="row">
            <div class="box">

              <?php if($recipe["ingredients"]) { ?>
                <div class="col-md-6">
                <h2>Ingredients</h2>
                <ul>
                  <?php foreach ($recipe["ingredients"] as $key => $value) { ?>
                    <li><?php echo $value; ?></li>
                  <?php } ?>
                </ul>
              </div>
              <?php } ?>
              <?php if($recipe["preparation_steps"]) { ?>
                <div class="col-md-6">
                <h2>Preparation</h2>
                <ul>
                  <?php foreach ($recipe["preparation_steps"] as $key => $value) { ?>
                    <li><?php echo $value; ?></li>
                  <?php } ?>
                </ul>
              </div>
              <?php } ?>
              <?php if($recipe["cooking_steps"]) { ?>
                <div class="col-md-6">
                <h2>Method</h2>
                <ul>
                  <?php foreach ($recipe["cooking_steps"] as $key => $value) { ?>
                    <li><?php echo $value; ?></li>
                  <?php } ?>
                </ul>
              </div>
              <?php } ?>
            </div>
        </div>

    </div>
   <?php
include('footer.php');
?>
