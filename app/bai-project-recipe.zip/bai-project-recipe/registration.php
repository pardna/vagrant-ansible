<html>
	<head>
		<link href="css/style.css" rel="stylesheet" type="text/css" />
	</head>
<body>
<div id="head-container">
	<div id="header">
		<h1>

		</h1>
	</div>
</div>
<div id="navigation-container">
	<div id="navigation">
		<ul>
			<li><a href="index.html"></a></li>
		</ul>
	</div>
</div>
<div id="content-container">
	<div id="content-container2">
		<div id="content-container3">
			<div id="content2">
				<h2>
					Welcome to bolton unversity recipe!
				</h2>
				<table width="300" border="0" align="center" cellpadding="0" cellspacing="1" bgcolor="#CCCCCC">
				<tr>
				<form name="form1" method="post" action="checkreg.php">
				<td>
				<table width="100%" border="0" cellpadding="3" cellspacing="1" bgcolor="#FFFFFF">
				<tr>
				<td colspan="3"><strong>Member Login </strong></td>
				</tr>
				<tr>
				<td width="150">Username</td>
				<td width="6">:</td>
				<td width="294"><input name="myusername" type="text" id="myusername"></td>
				</tr>
				<tr>
				<td>Password</td>
				<td>:</td>
				<td><input name="mypassword" type="text" id="mypassword"></td>
				</tr>
				<td>First Name</td>
				<td>:</td>
				<td><input name="myfname" type="text" id="myfname"></td>
				</tr>
				<td>Last Name</td>
				<td>:</td>
				<td><input name="mylname" type="text" id="mylname"></td>
				</tr>
				<td>Email</td>
				<td>:</td>
				<td><input name="myemail" type="text" id="myemail"></td>
				</tr>
				<tr>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td><input type="submit" name="Submit" value="Register"></td>
				</tr>
				</table>
				</td>
				</form>
				</tr>
				</table>
				<p>&nbsp;</p>
			</div>
		</div>
	</div>
	<div id="footer-container">
		<div id="footer">
	
		</div>
	</div>
</div>
</body>
</html>