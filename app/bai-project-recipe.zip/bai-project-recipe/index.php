<?php
include('header.php');
?>

<div class="container">

  <div class="row">
    <div class="box">
      <div class="col-lg-12 text-center">
        <div id="carousel-example-generic" class="carousel slide">
          <!-- Indicators -->
          <ol class="carousel-indicators hidden-xs">
            <li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
            <li data-target="#carousel-example-generic" data-slide-to="1"></li>
            <li data-target="#carousel-example-generic" data-slide-to="2"></li>
          </ol>

          <!-- Wrapper for slides -->
          <div class="carousel-inner">
              <?php foreach($tagService->getRecipeTags() AS $key => $tag) { ?>

                <div class="item <?php if($key == 0) { echo 'active'; } ?>">
                  <a href="recipes.php?id=<?php echo $tag["id"] ?>">
                  <img class="img-responsive img-full" src="<?php echo $imagePath . $tag["image"]; ?>" alt="$tag["name"]">
</a>
      <div class="carousel-caption">
        <h3><?php echo $tag["name"] ?> (<?php echo $tag["total"] ?>)</h3>
      </div>
                </div>

                <?php } ?>


          </div>

          <!-- Controls -->
          <a class="left carousel-control" href="#carousel-example-generic" data-slide="prev">
            <span class="icon-prev"></span>
          </a>
          <a class="right carousel-control" href="#carousel-example-generic" data-slide="next">
            <span class="icon-next"></span>
          </a>
        </div>
        <h2 class="brand-before">
          <small>Recipes </small>
        </h2>

      </div>
    </div>
  </div>

  </div>
</div>



</div>

</div>


</div>
</div>

</div>
<style type="text/css">
.carousel-content {
  position: absolute;
  bottom: 10%;
  left: 5%;
  z-index: 20;
  color: white;
  text-shadow: 0 1px 2px rgba(0,0,0,.6);
}
</style>
<?php
include('footer.php');
?>
