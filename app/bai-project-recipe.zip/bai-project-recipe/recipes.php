<?php
include('header.php');

$recipes = array();
if(isset($_GET["id"]) && $_GET["id"]) {
  $recipes = $recipeService->findByTagId($_GET["id"]);
} else if(isset($_GET["search"]) && $_GET["search"]) {
  $recipes = $recipeService->search($_GET["search"]);
} else {
  $recipes = $recipeService->getAll() ;
}
?>
    <div class="container">
        <div class="row">
            <div class="box">
                <?php foreach($recipes AS $recipe) { ?>
                  <div class="col-sm-6 col-md-4">
                    <div class="thumbnail">
                      <img src="<?php echo $imagePath . $recipe["image"]; ?>" alt="<?php echo $recipe["name"] ?>">
                      <div class="caption">
                        <h5><?php echo $recipe["name"] ?> </h5>
                        <p><a href="recipe.php?id=<?php echo $recipe["id"] ?>" class="btn btn-primary" role="button">View Recipe</a> </p>
                      </div>
                    </div>
                  </div>
                  <?php } ?>
                </div>
        </div>
    </div>
   <?php
include('footer.php');
?>
