-- Adminer 4.2.3 MySQL dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

DROP TABLE IF EXISTS `recipes`;
CREATE TABLE `recipes` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `preparation_time` varchar(255) NOT NULL,
  `cooking_time` varchar(50) NOT NULL,
  `preparation_steps` text NOT NULL,
  `cooking_steps` text NOT NULL,
  `ingredients` text NOT NULL,
  `serves` int(4) NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `fullname` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  FULLTEXT KEY `name` (`name`),
  FULLTEXT KEY `description` (`description`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

INSERT INTO `recipes` (`id`, `name`, `description`, `image`, `preparation_time`, `cooking_time`, `preparation_steps`, `cooking_steps`, `ingredients`, `serves`, `created`, `modified`, `user_id`, `fullname`) VALUES
(11,	'Jollof rice with fried plantains',	'Jollof rice is found throughout West Africa and is thought to be the origin of the Cajun dish, jambalaya. Serve with fried plantains and a crisp green salad.',	'recipe_42b368ab7bec3ad.jpg',	'less than 30 mins',	'1 to 2 hours',	'[]',	'[\"For the rice, heat the oil in a large pan and cook the onions over a gentle heat until translucent.\",\"Stir in the canned tomatoes, red pepper and tomato pur\\u00e9e, then season with salt, freshly ground black pepper and the cayenne or chilli. Add the curry powder, bay leaf and thyme, then pour in 550ml\\/19fl oz of water and crumble in the stock cube.\"]',	'[\"1 tbsp olive or vegetable oil\",\"2 large onions, sliced\",\"2 x 400g\\/14oz cans plum tomatoes\"]',	4,	'2016-04-30 16:32:27',	'2016-04-30 16:32:27',	4,	'Admin'),
(12,	'Southern-fried chicken and coleslaw',	'Marinating overnight in buttermilk is the secret to juicy, succulent chicken pieces. Try it in hot, peppery batter with crunchy coleslaw.',	'recipe_24a5db710f2b908.jpg',	'overnight',	'10 to 30 mins',	'[]',	'[\"Step 1\",\"Step 2\"]',	'[\"600ml\\/1 pint buttermilk\"]',	4,	'2016-05-03 20:58:03',	'2016-05-03 20:58:03',	4,	'Admin'),
(13,	'Spanish tomato bread',	'',	'recipe_90657f902ddb15a.jpg',	'less than 30 mins',	'no cooking required',	'[\"Toast the slices of bread on both sides until pale brown.\",\"Rub one side of each slice of toast with the cut side of a clove of garlic, using a new half garlic every couple of slices.\"]',	'[]',	'[\"1 loaf sourdough bread (or any crusty dense white bread), sliced into 6-8 thick slices\",\"3-4 garlic cloves, halved\"]',	8,	'2016-05-04 19:29:27',	'2016-05-04 19:29:27',	5,	'Bai Mustapha Jarju');

DROP TABLE IF EXISTS `recipe_tags`;
CREATE TABLE `recipe_tags` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `recipe_id` bigint(20) NOT NULL,
  `tag_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `recipe_id` (`recipe_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `recipe_tags` (`id`, `recipe_id`, `tag_id`) VALUES
(18,	11,	24),
(20,	12,	25),
(23,	13,	26);

DROP TABLE IF EXISTS `roles`;
CREATE TABLE `roles` (
  `role_id` int(11) NOT NULL AUTO_INCREMENT,
  `role_name` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`role_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `tags`;
CREATE TABLE `tags` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `parent_id` bigint(20) NOT NULL,
  `description` text NOT NULL,
  `image` varchar(255) NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `fullname` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  FULLTEXT KEY `name` (`name`),
  FULLTEXT KEY `description` (`description`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

INSERT INTO `tags` (`id`, `name`, `parent_id`, `description`, `image`, `created`, `modified`, `user_id`, `fullname`) VALUES
(21,	'January',	20,	'Forget cabbage soup: inject colour into a grey month with dazzling seasonal dishes. Pep up steamed puddings with January\'s star turns, Seville and blood oranges.',	'',	'2016-04-30 15:09:24',	'2016-04-30 15:09:24',	4,	'Admin'),
(20,	'In Season',	19,	'Seasonal food by month',	'',	'2016-04-30 15:08:08',	'2016-04-30 15:08:08',	4,	'Admin'),
(19,	'Recipes',	0,	'',	'',	'2016-04-30 15:07:14',	'2016-04-30 15:07:14',	4,	'Admin'),
(22,	'February',	20,	'Wage war on the cold with fortifying tagines, hearty stews and comfort food. Try roast venison with kale and or fish pies boasting fresh clams and mussels. Finish things off with rhubarb crumble.',	'',	'2016-04-30 15:09:20',	'2016-04-30 15:09:20',	4,	'Admin'),
(23,	'Cuisines',	0,	'Food around the world',	'tag_8bdaf457cc4f1e9.jpg',	'2016-04-30 16:05:10',	'2016-04-30 16:05:10',	4,	'Admin'),
(24,	'African',	23,	'',	'tag_1596ee6c5000a42.jpg',	'2016-04-30 15:11:07',	'2016-04-30 15:11:07',	4,	'Admin'),
(25,	'American',	23,	'',	'tag_9f9f45d8c498f74.jpg',	'2016-04-30 15:11:38',	'2016-04-30 15:11:38',	4,	'Admin'),
(26,	'Italian',	23,	'',	'tag_9fe2e75cecef696.jpg',	'2016-05-03 20:59:30',	'2016-05-03 20:59:30',	5,	'Bai Mustapha Jarju');

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `fullname` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `salt` varchar(255) NOT NULL,
  `role` varchar(10) DEFAULT NULL,
  `login_count` bigint(20) unsigned DEFAULT '0',
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `users` (`id`, `fullname`, `email`, `password`, `salt`, `role`, `login_count`, `created`, `modified`) VALUES
(4,	'Admin',	'admin@recipe.com',	'ea5baed0cd96d9259f07110bb0a5109e90ad1ea2e104ec4cde4a15431dae7177',	'DIzo7SA3KNCfeUct2tPBC5fC3FTHhinV',	'USER',	9,	'2016-04-28 21:39:24',	'2016-04-28 21:39:24'),
(5,	'Bai Mustapha Jarju',	'bai.jarju@recipe.com',	'681e92cade49595e489282d5c3fad4d76c0742c87d182d97ec983d0be9c70cb3',	'0T03is6YD3bGQaSAlweRMODGPxvaoJez',	'USER',	2,	'2016-05-03 20:57:54',	'2016-05-03 20:57:54');

-- 2016-05-07 12:12:33
