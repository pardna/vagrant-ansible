<?php
namespace App;
use Silex\Application;
class ServicesLoader
{
    protected $app;
    public function __construct(Application $app)
    {
        $this->app = $app;
    }
    public function bindServicesIntoContainer()
    {
      $this->app['users.service'] = $this->app->share(function () {
        $service = new Services\UsersService($this->app["db"]);
        return $service;
      });

      $this->app['tag.service'] = $this->app->share(function () {
        $service = new Services\TagService($this->app["db"]);

        return $service;
      });

      $this->app['recipe.service'] = $this->app->share(function () {
        $service = new Services\RecipeService($this->app["db"]);

        return $service;
      });




    }
}
