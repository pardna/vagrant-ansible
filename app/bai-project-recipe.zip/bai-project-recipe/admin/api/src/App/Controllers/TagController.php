<?php
/**
* Pardna groups
*
*/
namespace App\Controllers;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Security\Core\Exception\UsernameNotFoundException;
use Symfony\Component\HttpKernel\Exception\HttpException;

class TagController  extends AppController
{
  protected $tagService;

  protected $user;

  protected $app;

  public function __construct($service)
  {
    $this->tagService = $service;
  }

  public function getAll()
  {
    return new JsonResponse($this->tagService->getAll());
  }

  public function search(Request $request)
  {
    return new JsonResponse($this->tagService->getAll());
  }

  public function save(Request $request)
  {
    $tag = $this->getDataFromRequest($request);
    $this->tagService->setUser($this->getUser());
    $imageName = $this->upload("tag");
    if($imageName) {
      $tag["image"] = $imageName;
    }

    if(!isset($tag["id"])) {
      $userId = $this->tagService->save($tag);
      return new JsonResponse(array("message" => "Tag Saved", "tag" => $tag));
    } else {
      $userId = $this->tagService->update($tag);
      return new JsonResponse(array("message" => "Tag Updated", "tag" => $tag));
    }

  }

  public function get($id)
  {
    return new JsonResponse($this->tagService->findById(array("id" => $id)));
  }


  public function update(Request $request)
  {
    $tag = $this->getDataFromRequest($request);
    $userId = $this->tagService->update($tag);
    return new JsonResponse(array("message" => "Tag Updated"));
  }

  public function getDataFromRequest(Request $request)
  {
    return  $request->request->all();
  }

}
