<?php
/**
* Pardna groups
*
*/
namespace App\Controllers;
class AppController
{
  protected $user;
  protected $service;
  protected $app;

  public function __construct($service)
  {
    $this->service = $service;
  }

  public function setUser($user) {
    $this->user = $user;
    return $this;
  }

  public function getUser() {
    return $this->user;
  }

  public function setApp($app) {
    $this->app = $app;
    return $this;
  }

  public function getApp() {
    return $this->app;
  }

  public function upload($type) {
    if (isset($_FILES['file']) && $_FILES['file']['error'] == 0) {

      $temp = explode(".", $_FILES["file"]["name"]);
      $newfilename = $type . "_" . substr(md5(time()), 0, 15) . '.' . end($temp);
      move_uploaded_file($_FILES['file']['tmp_name'], 'images/' . $newfilename);
      return $newfilename;
    }
    return null;
  }

}
