<?php
/**
* Pardna groups
*
*/
namespace App\Controllers;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Security\Core\Exception\UsernameNotFoundException;
use Symfony\Component\HttpKernel\Exception\HttpException;

class RecipeController  extends AppController
{
  protected $recipeService;

  protected $user;

  protected $app;

  public function __construct($service)
  {
    $this->recipeService = $service;
  }

  public function getAll()
  {
    return new JsonResponse($this->recipeService->getAll());
  }

  public function search(Request $request)
  {
    return new JsonResponse($this->recipeService->getAll());
  }

  public function save(Request $request)
  {
    $tag = $this->getDataFromRequest($request);
    $this->recipeService->setUser($this->getUser());
    $imageName = $this->upload("recipe");
    if($imageName) {
      $tag["image"] = $imageName;
    }

    if(!isset($tag["id"])) {
      $userId = $this->recipeService->save($tag);
      return new JsonResponse(array("message" => "Recipe Saved", "recipe" => $tag));
    } else {
      $userId = $this->recipeService->update($tag);
      return new JsonResponse(array("message" => "Recipe Updated", "recipe" => $tag));
    }

  }

  public function get($id)
  {
    return new JsonResponse($this->recipeService->findById(array("id" => $id)));
  }



  public function getDataFromRequest(Request $request)
  {
    return  $request->request->all();
  }

}
