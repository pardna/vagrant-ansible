<?php
/**
* Pardna groups
*
*/
namespace App\Controllers;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Security\Core\Exception\UsernameNotFoundException;
use Symfony\Component\HttpKernel\Exception\HttpException;

class UsersController
{
  protected $usersService;

  protected $user;

  protected $app;

  public function __construct($service)
  {
    $this->usersService = $service;
  }
  public function getAll()
  {
    return new JsonResponse($this->usersService->getAll());
  }

  public function setUser($user) {
    $this->user = $user;
  }

  public function getUser() {
    return $this->user;
  }

  public function setApp($app) {
    $this->app = $app;
  }

  public function getApp() {
    return $this->app;
  }

  public function get($id)
  {
    return new JsonResponse($this->usersService->get($id));
  }

  public function login(Request $request) {
    $vars = $request->request->all();
    if (empty($vars['username']) || empty($vars['password'])) {
        throw new UsernameNotFoundException(sprintf('Username "%s" does not exist.', $vars['username']));
    }
    return $this->_login($vars["username"], $vars["password"]);
  }

  private function _login($username, $password) {
    $app = $this->app;
    $vars = array(
      "username" => $username,
      "password" => $password
    );
    try {

        /**
         * @var $user User
         */
        $user = $app['users']->loadUserByUsername($vars['username']);
        if (!$app['users']->authenticate($vars['username'], $vars['password'])) {
          $response = [
              'success' => false,
              'error' => 'Invalid credentials',
              'user' => $vars
          ];
        } else {
            $response = $this->jwtArray($user);
            $this->usersService->incrementLoginCount($user->getId());
        }
    } catch (UsernameNotFoundException $e) {
        $response = [
            'success' => false,
            'error' => 'Invalid credentials',
          //  'user' => $vars
        ];
    }
    $code = $response['success'] == true ? JsonResponse::HTTP_OK : JsonResponse::HTTP_BAD_REQUEST;
    return new JsonResponse($response, $code);
  }

  protected function getTokenArray() {
    $app = $this->app;
    $user = $app['users']->loadUserByUsername($this->getUser()->getUsername());
    return $this->jwtArray($user);
  }

  public function refreshToken() {

    return new JsonResponse($this->getTokenArray());
  }

  protected function jwtArray($user) {
    $app = $this->app;
     return [
        'success' => true,
        'token' => $app['security.jwt.encoder']->encode([
          'fullname' => $user->getFullName(),
          "name" => $user->getEmail(),
          "email" => $user->getEmail(),
          "login_count" => $user->getLoginCount(),
          "role" => $user->getRole(),
          "id" => $user->getId(),
          ]),
    ];
  }

  public function signup(Request $request)
  {
    $user = $this->getDataFromRequest($request);
    $userId = $this->usersService->save($user);
    return $this->_login($user["email"], $user["password"]);
  }

  public function signin(Request $request)
  {
    $user = $this->getDataFromRequest($request);
    return new JsonResponse(array("id" => $this->usersService->save($user)));
  }

  public function changePassword(Request $request)
  {
    $user = $this->getDataFromRequest($request);
    if ($this->usersService->authenticate($user["email"], $user["currentPassword"])){
      return new JsonResponse(array("id" => $this->usersService->changePassword($user["email"], $user["newPassword"])));
    }
  }

  public function resetPassword($t, Request $request)
  {
    $user = $this->getDataFromRequest($request);
    if ($this->usersService->validateResetPasswordToken($t)){
      return new JsonResponse(array("id" => $this->usersService->changePassword($user["email"], $user["newPassword"])));
    }
  }


  public function update($id, Request $request)
  {
    $user = $this->getDataFromRequest($request);
    $this->usersService->update($id, $user);
    return new JsonResponse($user);
  }

  public function delete($id)
  {
    return new JsonResponse($this->usersService->delete($id));
  }


  public function getDataFromRequest(Request $request)
  {
    return  $request->request->get("user");
  }

}
