<?php
namespace App\Services;
// move http exceptiosn to controller
use Symfony\Component\HttpKernel\Exception\HttpException;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;

class RecipeService extends BaseService
{

  protected $table = "recipes";
  protected $recipeTagsTable = "recipe_tags";
  protected $tagsTable = "tags";

  function update($data)
  {
    if(isset($data['$$hashKey'])) {
      unset($data['$$hashKey']);
    }
    $data = $this->appendCreatedModified($data);
    $data["preparation_steps"] = isset($data["preparation_steps"]) && $data["preparation_steps"] ? json_encode($data["preparation_steps"]) : json_encode(array());
    $data["cooking_steps"] = isset($data["cooking_steps"]) && $data["cooking_steps"] ? json_encode($data["cooking_steps"]) : json_encode(array());
    $data["ingredients"] = isset($data["ingredients"]) && $data["ingredients"] ? json_encode($data["ingredients"]) : json_encode(array());

    $tags = isset($data["tags"]) && is_array($data["tags"]) ? $data["tags"] : array();
    if(isset($data["tags"])) {
      unset($data["tags"]);
    }

    if($this->findById($data)) {
      $this->db->update($this->table, $data, array("id" => $data["id"]));
      $this->updateTags($data["id"], $tags);
      return $data["id"];
    }
    return false;
  }

  function save($data)
  {
    $data = $this->appendCreatedModified($data);
    $data = $this->appendUser($data);

    $data["preparation_steps"] = isset($data["preparation_steps"]) && $data["preparation_steps"] ? json_encode($data["preparation_steps"]) : json_encode(array());
    $data["cooking_steps"] = isset($data["cooking_steps"]) && $data["cooking_steps"] ? json_encode($data["cooking_steps"]) : json_encode(array());
    $data["ingredients"] = isset($data["ingredients"]) && $data["ingredients"] ? json_encode($data["ingredients"]) : json_encode(array());

    $tags = isset($data["tags"]) && is_array($data["tags"]) ? $data["tags"] : array();
    if(isset($data["tags"])) {
      unset($data["tags"]);
    }
    if(!$this->exists($data)) {
      $this->db->insert($this->table, $data);
      $id = $this->db->lastInsertId();
      $this->updateTags($id, $tags);
      return $id;
    }
    return false;

  }

  function updateTags($recipeId, $tags) {
    $this->db->delete($this->tagsTable, array('recipe_id' => $recipeId));
    if($tags && is_array($tags)) {
      foreach($tags as $tagId) {
        $this->db->insert($this->tagsTable, array("recipe_id" => $recipeId, "tag_id" => $tagId));
      }
    }
  }

  public function exists($recipe)
  {
    return $this->db->fetchAssoc("SELECT * FROM {$this->table} WHERE name = ? LIMIT 1", array($recipe["name"]));
  }

  public function findById($recipe)
  {
    $data = $this->db->fetchAssoc("SELECT * FROM {$this->table} WHERE id = ? LIMIT 1", array($recipe["id"]));
    if($data) {
      $data["preparation_steps"] = $data["preparation_steps"] ? json_decode($data["preparation_steps"]) : array();
      $data["cooking_steps"] = $data["cooking_steps"] ? json_decode($data["cooking_steps"]) : array();
      $data["ingredients"] = $data["ingredients"] ? json_decode($data["ingredients"]) : array();
    }
    $data["tags"] = $this->getTagIds($data);
    return $data;
  }

  public function findByTagId($id)
  {
    $data = $this->db->fetchAll("SELECT r.* FROM {$this->table} r RIGHT JOIN {$this->recipeTagsTable} rt ON r.id = rt.recipe_id WHERE rt.tag_id = ? LIMIT 5000", array($id));

    return $data;
  }

  public function getTagIds($recipe)
  {
    $results = $this->db->fetchAll("SELECT * FROM {$this->recipeTagsTable} WHERE recipe_id = ? ORDER BY id DESC LIMIT 5000", array($recipe["id"]));
    $data = array();
    if($results) {
      foreach($results as $result) {
        $data[] = $result["tag_id"];
      }
    }
    return $data;
  }

  public function search($term)
  {
    if($term) {
      $term = $term . "*";
    }
    $results = $this->db->fetchAll("
    SELECT r.*, MATCH(t.name, t.description, r.name, r.description) AGAINST (? IN BOOLEAN MODE) AS relevancy
    FROM {$this->table} r
RIGHT JOIN {$this->recipeTagsTable} rt ON r.id = rt.recipe_id
RIGHT JOIN {$this->tagsTable} t ON t.id = rt.tag_id
WHERE r.id IS NOT NULL
HAVING relevancy > 0
ORDER BY relevancy DESC LIMIT 5000", array($term));

    return $results;
  }


  public function getAll()
  {

    return $this->db->fetchAll("SELECT * FROM {$this->table} ORDER BY id DESC LIMIT 5000");
  }



}
