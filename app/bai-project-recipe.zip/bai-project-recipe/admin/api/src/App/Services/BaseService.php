<?php
namespace App\Services;
class BaseService
{
    protected $db;
    protected $table;
    protected $user;

    public function __construct($db)
    {
        $this->db = $db;
    }

    public function appendCreatedModified($data) {
      $data = $this->appendCreated($data);
      $data = $this->appendModified($data);
      return $data;
    }

    public function setUser($user) {
      $this->user = $user;
    }

    public function getUser() {
      return $this->user;
    }

    public function appendCreated($data) {
      return $this->appendDate("created", $data);
    }

    public function appendModified($data) {
      return $this->appendDate("modified", $data);
    }

    public function appendUser($data) {
      if($this->getUser()) {
        $data["user_id"] = $this->getUser()->getId();
        $data["fullname"] = $this->getUser()->getFullname();
      }
      return $data;
    }

    protected function appendDate($key, $data) {
      $data[$key] = date("Y-m-d H:i:s");
      return $data;
    }

    public function setTable($table) {
      $this->table = $table;
      return $this;
    }

    public function getTable() {
      return $this->table;
    }

  


}
