<?php
namespace App\Services;
// move http exceptiosn to controller
use Symfony\Component\HttpKernel\Exception\HttpException;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;

class TagService extends BaseService
{

  protected $table = "tags";
    protected $tagRecipeTable = "recipe_tags";

  function update($data)
  {
    $data = $this->appendCreatedModified($data);
    if(isset($data['$$hashKey'])) {
      unset($data['$$hashKey']);
    }
    if($this->findById($data)) {
      $this->db->update($this->table, $data, array("id" => $data["id"]));
      return $data["id"];
    }
    return false;
  }

  function save($data)
  {
    $data = $this->appendCreatedModified($data);
    $data = $this->appendUser($data);
    if(!$this->exists($data)) {
      $this->db->insert($this->table, $data);
      return $this->db->lastInsertId();
    }
      return false;

  }

  public function exists($tag)
  {
    return $this->db->fetchAssoc("SELECT * FROM {$this->table} WHERE name = ? LIMIT 1", array($tag["name"]));
  }

  public function findById($tag)
  {
    return $this->db->fetchAssoc("SELECT * FROM {$this->table} WHERE id = ? LIMIT 1", array($tag["id"]));
  }


  public function getAll()
  {

    return $this->db->fetchAll("SELECT * FROM {$this->table} LIMIT 5000");
  }

  public function getRecipeTags()
  {

    return $this->db->fetchAll("
        SELECT  t.*, count(tr.id) AS total FROM {$this->table} t
        RIGHT JOIN {$this->tagRecipeTable} tr ON tr.tag_id = t.id
        GROUP BY t.id
        ORDER BY t.name ASC LIMIT 5000
    ");
  }

  public function search($term) {

  }

}
