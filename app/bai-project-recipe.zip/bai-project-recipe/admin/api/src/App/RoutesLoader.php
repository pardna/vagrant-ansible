<?php
namespace App;
use Silex\Application;
class RoutesLoader
{
    private $app;
    public function __construct(Application $app)
    {
        $this->app = $app;
        $this->instantiateControllers();
    }
    private function instantiateControllers()
    {
        $this->app['users.controller'] = $this->app->share(function () {
            $controller = new Controllers\UsersController($this->app['users.service']);
            $controller->setApp($this->app);
            if($this->app['security.token_storage']->getToken()->getUser()) {
              $controller->setUser($this->app['security.token_storage']->getToken()->getUser());
            }
            return $controller;
        });

        $this->app['tag.controller'] = $this->app->share(function () {
            $controller = new Controllers\TagController($this->app['tag.service']);
            $controller->setApp($this->app);
            if($this->app['security.token_storage']->getToken()->getUser()) {
              $controller->setUser($this->app['security.token_storage']->getToken()->getUser());
            }
            return $controller;
        });

        $this->app['recipe.controller'] = $this->app->share(function () {
            $controller = new Controllers\RecipeController($this->app['recipe.service']);
            $controller->setApp($this->app);
            if($this->app['security.token_storage']->getToken()->getUser()) {
              $controller->setUser($this->app['security.token_storage']->getToken()->getUser());
            }
            return $controller;
        });



    }


    public function bindRoutesToControllers()
    {
        $api = $this->app["controllers_factory"];
        $api->get('/user/{id}', "users.controller:get");
        $api->post('/signup', "users.controller:signup");
        $api->post('/login', "users.controller:login");
        $api->get('/login', "users.controller:login");
        $api->post('/refresh-token', "users.controller:refreshToken");
        $api->post('/signin', "users.controller:signin");
        $api->post('/user/change-password', "users.controller:changePassword");
        $api->put('/user/{id}', "users.controller:update");
        $api->delete('/user/{id}', "users.controller:delete");

        $api->post('/tag', "tag.controller:save");
        $api->post('/tag/update', "tag.controller:save");
        $api->get('/tag', "tag.controller:getAll");

        $api->get('/tag/search', "tag.controller:search");

        $api->post('/recipe', "recipe.controller:save");
        $api->post('/recipe/update', "recipe.controller:save");
        $api->get('/recipe', "recipe.controller:getAll");
        $api->get('/recipe/{id}', "recipe.controller:get");
        $api->get('/recipe/search', "recipe.controller:search");

        $this->app->mount($this->app["api.endpoint"].'/'.$this->app["api.version"], $api);
    }
}
