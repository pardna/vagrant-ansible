<?php
$app['log.level'] = Monolog\Logger::ERROR;
$app['api.version'] = "v1";
$app['api.endpoint'] = "/api";

$app['db.options'] = array(
  'driver'    => 'pdo_mysql',
  'host'      => '127.0.0.1',
  'dbname'    => 'recipe_db',
  'user'      => 'root',
  'password'  => '123'
  // 'charset'   => 'utf8mb4',
);
