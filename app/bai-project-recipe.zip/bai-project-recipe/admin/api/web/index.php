<?php

require_once __DIR__.'/../vendor/autoload.php';

use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Security\Core\Exception\UsernameNotFoundException;
use Symfony\Component\Security\Core\User\InMemoryUserProvider;
use Symfony\Component\Security\Core\User\User;
$app = new Silex\Application();
header("Access-Control-Allow-Origin: *");
header('Access-Control-Allow-Methods: GET,POST,PUT,DELETE,OPTIONS');
header("Access-Control-Allow-Headers: X-Requested-With");

require __DIR__ . '/../resources/config/dev.php';
require __DIR__ . '/../src/app.php';

ini_set('display_errors', 1);
error_reporting(~0);

$app['http_cache']->run();
